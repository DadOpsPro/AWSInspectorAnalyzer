# Standard Operating Procedure
## Two-Week Review of Uncontrolled Mythos / AI Security Scans

**Audience:** AppSec + application owners on a legacy application  
**Cadence this SOP is built for:** 10 working days to review and return `handback.md`, then a new scan ~5 working days later with little or no remediation window  
**Success metric:** 100% of Highs *dispositioned* before handback. Remediation is a separate program.

---

## 0. Principles (pin these on the wall)

1. **Scanner High ≠ ticket.** It is a claim. Your job is a verdict.
2. **Fix the cadence you cannot change by making memory.** The ledger and dismissal rules are the product. Individual scan reports are raw material.
3. **Cluster before you read.** One root cause, one review, one LoE, many scanner IDs.
4. **Agents propose. Humans own P0/P1 and anything that would change production.**
5. **Do not apologize in the handback for not shipping fixes.** State the constraint, the dispositions, and the remediation plan. That is professional, not evasive.
6. **Never re-triage a finding whose code and claim did not change.** Match it and inherit the last verdict.

---

## 1. Roles

| Role | Owns |
|---|---|
| **Review lead** (AppSec or senior engineer) | Cadence, handback quality, P0 calls, stakeholder comms |
| **App owner / SME** | Trust boundaries, “is this even shipped?”, change risk |
| **Agent operator** | Runs prompts 01–05, keeps ledger clean, flags `needs_human` |
| **Engineering manager** | Accepts LoE and sequencing; does *not* reopen FPs without new evidence |

Two people can cover this. Do not staff 96 individual reviewers.

---

## 2. Verdict vocabulary (use only these)

| Verdict | Meaning | Handback treatment |
|---|---|---|
| `confirmed_reachable` | Untrusted input can reach the sink in a shipped surface | Open issue, our severity, LoE |
| `confirmed_not_reachable` | Bug is real in code; path is not live in our deploy | Document; usually no emergency fix |
| `duplicate` | Same root cause as another finding / cluster | Point to parent ID |
| `false_positive` | Claim fails against this commit (wrong line, invented API, mitigated, dead code) | Dismiss with evidence |
| `accepted_risk` | Real enough, will not fix this cycle (legacy constraint, compensating control, change risk) | Named owner + review date |
| `out_of_scope` | Module not shipped, vendor code you cannot change, lab-only | Dismiss with scope note |
| `needs_poc` | Static reasoning exhausted; only used for suspected P0 | Park with owner; do not block handback |
| `needs_human` | Agent could not finish safely | Review lead within 24h |

**Our severity** (ignore scanner severity except as a sort hint):

| Ours | Preconditions |
|---|---|
| P0 | Unauthenticated (or trivially authenticated) remote path, real trust-boundary crossing, sensitive impact |
| P1 | Authenticated or 1–2 extra conditions, still a shipped surface |
| P2 | Admin-only, local, 3+ preconditions, non-default flag, limited blast radius |
| P3 | Defense-in-depth / hygiene / theoretical |

LoE is T-shirt on the *cluster*, not the finding:

- **S** = hours (guard, bind parameter, canonicalize)
- **M** = 1–3 days (shared helper + call-site sweep + tests)
- **L** = 1–2 sprints (auth/session/parser change)
- **XL** = program of work (architecture)

Add **change-risk**: `low` / `medium` / `high` (no tests, frozen vendor module, shared kernel).

---

## 3. Two-week calendar

Assumes findings arrive Monday of week 1. Shift the days; keep the proportions.

### Day 0 (intake, 2–3 hours) — do not open Jira

- Register the scan on the **Scans** sheet (ID, date, model/product, commit, artifact list, raw counts).
- Confirm `THREAT_MODEL.md` is current. If not, 45 minutes with the SME: internet vs internal, auth model, what is actually shipped.
- Drop artifacts + threat model + dismissal rules + prompt `01` into the agent.
- Agent output required: clustered candidate list, proposed verdicts, `needs_human` list. No tickets yet.

**Exit:** cluster count known. Target: 96 Highs → 8–20 clusters.

### Days 1–2 (mass disposition, 6–8 hours)

- Auto-accept agent verdicts for: exact duplicates, prior-scan matches with unchanged code, obvious `out_of_scope`, dismissal-rule hits.
- Human spot-check 10% of those auto-accepts (especially “Dropped” from their `triage.md`).
- SME spends 90 minutes on “is this surface shipped / reachable in prod?”
- Everything else stays `needs_human` or `needs_poc`.

**Exit:** ≥70% of Highs have a non-`needs_human` verdict.

### Days 3–5 (verify P0/P1 clusters only)

- One cluster per prompt-`02` session. Cap at 30 minutes static review per cluster.
- Confirm: cited file:line exists; data flow is real; preconditions listed; our severity assigned.
- Do **not** build exploits unless the cluster is a plausible P0 and the handback would otherwise over-claim.
- Write the intended fix *shape* (not a patch). Example: “parameterize `search()` in `LegacyDao` and sweep 14 call sites.”

**Exit:** every suspected P0/P1 cluster has our severity + LoE + change-risk.

### Day 6 (tickets and sequencing)

- Prompt `03`. One ticket per cluster, scanner IDs in the body.
- Sequence by: P0 reachable → P1 reachable + low change-risk → everything else.
- Explicitly mark “will not start before next scan.” That sentence belongs in the handback.

### Days 7–8 (compose handback)

- Prompt `04` drafts `HANDBACK.md` from the ledger. Humans edit tone and facts only.
- Include: what you reviewed, what you confirmed, what you rejected and why, what you will not fix this cycle, what you need from the scanning party (commit pinning, delta reports, stop re-reporting dismissed sinks).
- Attach or link the ledger export.

### Days 9–10 (buffer + stakeholder)

- Review lead + EM sign the handback.
- Update `DISMISSAL_RULES.md` with every new standing rule this scan taught you.
- Pre-stage prompt `05` for the next drop so week 3 is a delta, not a reboot.

---

## 4. Working the artifacts you are given

Read in this order, once:

1. Their `handback.md` (what they already think is confirmed)
2. Their `triage.md` Act-on-these section
3. Machine-readable findings (JSON / SARIF / jsonl) — this feeds the ledger
4. A sample of their Dropped table (trust-but-verify)
5. Anything labeled recon / threat model — compare to *yours*

Do not let the team read 96 narrative exploit writeups. Agents summarize; humans check code.

---

## 5. Matching findings across scans (how you survive week 3)

A finding from scan N+1 is the **same work item** if any of these hold:

- Same `file` + same CWE/class + line within 15 lines
- Same sink function + same source class of input
- Agent semantic match *and* a human agrees the same patch would close both

Then: inherit verdict, inherit cluster, mark `prior_scan_ref`. Only reopen if the **code changed** or the **claim gained a new reachable path**.

This is the entire strategy for “we get another 90 Highs a week after handback.”

---

## 6. What to ask the scanning party (every handback)

You cannot stop the cadence. You can demand a usable package:

1. Pin the exact commit / tag scanned. No commit, no Highs accepted as new.
2. Deliver JSON/SARIF, not only prose.
3. Respect your dismissal file: do not re-open a sink you dismissed with evidence unless the file changed.
4. Give a **delta report** (new / unchanged / gone) instead of a full dump.
5. Separate “first-seen this model version” from “still present.”
6. Stop inflating severity without listing preconditions.

Put these in the handback as **Asks**. Repeat them every cycle until they stick.

---

## 7. Governance you can use internally

When leadership asks “why aren’t the 96 Highs fixed?” answer with the dashboard:

- Highs received vs Highs dispositioned (should be equal at handback)
- Confirmed reachable P0/P1 count (this is the real number)
- Clusters, not findings
- LoE of the confirmed set
- Constraint: remediation window is zero by calendar, not by neglect

Do not let raw scanner counts into status slides.

---

## 8. Guardrails for agentic review

- Agents are read-only against production. No live exploit against prod.
- Agents must cite `file:line` from *this* commit. Hallucinated paths = `false_positive` or `needs_human`.
- Agents may not invent CVSS numbers. They may propose a vector; humans / a calculator score it if needed.
- Agents may not mark `accepted_risk`. That is a human decision.
- Every agent session starts with `prompts/00-system-constraints.md` + current threat model + dismissal rules.

---

## 9. Definition of done

A cycle is done when all of these are true:

- [ ] Scan registered and commit recorded
- [ ] Every High has a verdict
- [ ] Every confirmed item lives in a cluster with LoE
- [ ] `HANDBACK.md` signed
- [ ] `DISMISSAL_RULES.md` updated
- [ ] Ledger saved as the input to the next scan
- [ ] No one started 96 tickets
