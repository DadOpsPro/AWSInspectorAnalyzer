# Threat model — [APPLICATION NAME]

Fill this once. Update only when architecture or exposure changes.
Every agent session must read this file before touching findings.

## Identity

- Application:
- Repo / path:
- Typical release vehicle (WAR / VM / mainframe companion / vendor overlay):
- Environments that matter: prod / DR / vendor-hosted / internal-only
- Data classes: (PII, payment, credentials, PHI, none of the above)

## What is actually shipped

List the modules that exist in production. Anything not listed is out of scope for P0.

| Module / package | Shipped? | Internet-facing? | Auth required? | Notes |
|---|---|---|---|---|
| | yes/no | yes/no | none/user/admin | |

## Trust boundaries

1. Unauthenticated internet
2. Authenticated customer / partner
3. Authenticated employee / operator
4. Privileged admin / break-glass
5. Batch / operator workstation / jump host
6. Trusted back-end (service accounts, queue, file drop)

Write which code lives on which side, in one paragraph.

## Entry points that matter

- HTTP/SOAP/REST:
- File / FTP / queue:
- Batch jobs:
- Admin consoles:
- Integration partners:

## AuthN / AuthZ facts the scanner will get wrong

- How sessions work
- Where authorization is enforced (gateway, filter, each controller, none)
- Shared secrets, static keys, “trust the intranet”
- Impersonation / break-glass paths

## Compensating controls that are real

Only list controls that exist *and* would stop the class of bug.
Examples: network ACL so module X is not internet-reachable; WAF only if you will bet a P0 on it; mTLS between services.

## What we do not treat as a vulnerability

Standing scope exclusions. Keep short.

- Findings that require admin on the app server already
- Findings in modules listed “not shipped”
- Theoretical attacks that need a compromised operator desktop *and* no additional impact
- Code-quality / robustness issues with no security boundary crossed

## Crown jewels

If these are reachable without auth (or after a single guessable step), it is P0.

-

## SME contacts

- Who can say “this is not deployed”:
- Who can say “this path is live in prod”:
