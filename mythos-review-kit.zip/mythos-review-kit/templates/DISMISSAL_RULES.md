# Standing dismissal and matching rules

This file is the memory that survives each scan. Agents must apply it before proposing a new ticket.
Add a dated rule every time you dismiss a repeating class.

## How to add a rule

```
### R-YYYMMDD-## — short name
- Applies to: CWE / sink / module
- Verdict: false_positive | out_of_scope | accepted_risk | confirmed_not_reachable
- Evidence: file, control, or deploy fact
- Reopen only if: concrete condition
```

## Matching

Treat a new scanner finding as the same work item when:

1. Same path + same class + line within 15 lines, or
2. Same sink function + same untrusted source class, or
3. Semantic duplicate of an existing cluster (one patch would close both)

Then copy the previous verdict. Do not re-investigate unless the reopen condition is met.

## Seed rules (edit or delete)

### R-20260908-01 — scanner severity is not our severity
- Applies to: all findings
- Verdict: re-rank using preconditions in the SOP
- Evidence: AI scanners label by bug class, not by our deploy
- Reopen only if: n/a (always apply)

### R-20260908-02 — admin-only operator tools are not P0
- Applies to: surfaces that already require app-server or operator admin
- Verdict: P2 or out_of_scope unless they expand privilege beyond admin
- Evidence: threat model trust boundary 4–5
- Reopen only if: the surface is shown reachable without that admin

### R-20260908-03 — not-shipped modules
- Applies to: modules marked “Shipped? no” in THREAT_MODEL.md
- Verdict: out_of_scope
- Evidence: threat model table
- Reopen only if: the module is enabled in a production package

### R-20260908-04 — hallucinated locations
- Applies to: any finding whose file, symbol, or line does not exist on the scanned commit
- Verdict: false_positive
- Evidence: checkout of that commit
- Reopen only if: the path exists on a later commit and the claim is restated

## Rules added this engagement

(append below)
