# Handback — [APPLICATION] — Scan [SCAN_ID]

| Field | Value |
|---|---|
| Application | |
| Scan ID / package date | |
| Scanned commit / tag | |
| Review window | YYYY-MM-DD → YYYY-MM-DD |
| Review lead | |
| Returned | YYYY-MM-DD |
| Next expected scan | YYYY-MM-DD (if known) |

## 1. Constraint (say this once, clearly)

This handback is a **disposition of scanner claims**, not a remediation report.

The review calendar does not include an implementation window. Confirmed items are sequenced for engineering; they will still be present on the next scan. Please treat re-reports of unchanged, already-dispositioned sinks as **duplicates**, not new Highs.

## 2. Package we reviewed

- Artifacts received:
- Raw counts (scanner): Critical __ / High __ / Medium __ / Low __
- Commit confirmed? yes/no

## 3. What we did

- Threat model used: `THREAT_MODEL.md` dated ____
- Findings ingested: __
- Clusters formed: __
- Human-verified clusters: __ (all suspected P0/P1)
- Agent-assisted first pass: yes

We did **not** attempt production exploits. Verification is static reachability against the scanned commit plus SME deploy facts.

## 4. Scoreboard (our labels, not the scanner’s)

| Bucket | Findings | Clusters |
|---|---:|---:|
| Confirmed reachable — P0 | | |
| Confirmed reachable — P1 | | |
| Confirmed reachable — P2/P3 | | |
| Confirmed, not reachable in our deploy | | |
| False positive | | |
| Out of scope | | |
| Duplicate (collapsed into a parent) | | |
| Accepted risk | | |
| Needs PoC / still open | | |
| **Total Highs dispositioned** | | — |

Disposition rate for scanner Highs: __%

## 5. Confirmed reachable — act on these

One subsection per cluster. Scanner IDs belong here so the next scan can match.

### C-001 — [title]

- Scanner IDs:
- Our severity: P0 / P1
- Location:
- Why it is real in *this* product:
- Preconditions:
- Intended fix shape:
- LoE / change-risk:
- Owner:
- Will not be implemented before next scan: **yes**

## 6. Confirmed but not a production emergency

Clusters that are real in code and not reachable as deployed, or P2/P3 hygiene.

| Cluster | Why it is not P0 | Disposition |
|---|---|---|
| | | confirmed_not_reachable / P2 / accepted_risk |

## 7. Rejected claims

Summarize by *rule*, not by finding. Attach the ledger if they want the long list.

| Rule / reason | Count | Example scanner IDs |
|---|---:|---|
| Hallucinated file or symbol | | |
| Mitigated on path / existing guard | | |
| Not shipped | | |
| Duplicate of C-___ | | |
| Admin-only, no extra impact | | |

## 8. Accepted risks

| Cluster / ID | Risk statement | Compensating control | Review date | Approver |
|---|---|---|---|---|
| | | | | |

## 9. Asks of the scanning party

Please do these on the next package. They reduce duplicate labor; they do not reduce security.

1. Pin and print the exact commit / tag in every artifact.
2. Ship JSON or SARIF alongside markdown.
3. Send a **delta**: new / still-present-unchanged / gone. Do not send a full High list as if it were new work.
4. Honor `DISMISSAL_RULES.md` and prior handback IDs. Re-open only if the file changed or a new path is shown.
5. List preconditions next to severity. A High with three unstated knobs is a Medium until proven otherwise.

## 10. Attachments

- Disposition ledger export (date)
- Threat model (date)
- Dismissal rules (date)

## Sign-off

| Role | Name | Date |
|---|---|---|
| Review lead | | |
| App owner / SME | | |
| Engineering manager (LoE acknowledged) | | |
