# Jira export for the master index

Pull every ticket the first two rounds created from Units, plus any R3 tickets.

## JQL starter

Adjust project and labels to match what you used:

```
project = YOURPROJ AND (
  labels in (mythos, glasswing, security-scan, handback)
  OR summary ~ "Unit"
  OR "Scan Round" is not EMPTY
)
ORDER BY key ASC
```

If R1/R2 tickets were not labeled, export by the sprint / epic / component you dumped them into, or by created date covering those two review windows.

## Columns to include

Required:

- Key
- Summary
- Status
- Assignee
- Created
- Updated
- Priority
- Labels
- Description (at least the Unit ID if it lives there)

Add if you have them:

- Parent / Epic
- Custom field that holds Unit ID
- Custom field that holds Scan / Round
- Story points or original estimate (R3 LoE may have landed here)

## After export

1. Paste onto **Tickets** in `Master-Index.xlsx`.
2. Fill **Unit ID** by hand for the first 20 if it is only in the summary (`Unit 12`, `U-012`, `UNIT-AUTH-3`, whatever the vendor called it). An agent with prompt 06 can extract Unit IDs from summaries and descriptions.
3. Do not cleanse status names — keep Jira’s (`To Do`, `In Progress`, `Done`, `Closed`, …). The sheet maps them.

## What good looks like

| Key | Summary | Unit ID | Status | Created from |
|---|---|---|---|---|
| APP-1842 | Unit 7 — legacy search / data access | U-007 | To Do | R1 |
| APP-1901 | Unit 7 additional findings | U-007 | To Do | R2 |

Those two rows should collapse to **one Work Item** with both keys listed, not two engineering streams.
