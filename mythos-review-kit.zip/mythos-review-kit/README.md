# Mythos / AI Scan Review Kit

A two-week operating package for teams that **receive** Mythos / Claude Security / Glasswing-style scan packages, do not control scan cadence, and must return an updated `handback.md` before the next scan arrives.

## What this kit assumes

- Scans are outside your control.
- You have ~10 working days to review and hand back.
- ~1 week after handback, a new scan lands.
- You will **not** implement most fixes between scans.
- You use agentic tools to accelerate review, not to rubber-stamp scanner severity.
- Success is **100% Highs dispositioned**, not 100% Highs fixed.

## Files

| File | Purpose |
|---|---|
| `SOP-two-week-review.md` | Day-by-day operating procedure |
| `Mythos-Scan-Review-SOP.docx` | Same SOP as a shareable Word doc |
| `Disposition-Ledger.xlsx` | Tracker, clustering, dashboard, lookup lists |
| `templates/THREAT_MODEL.md` | One-page threat model the agents must read first |
| `templates/HANDBACK.md` | Return package you send back |
| `templates/DISMISSAL_RULES.md` | Standing FP / scope rules that persist across scans |
| `prompts/00-system-constraints.md` | Standing instructions for every agent session |
| `prompts/01-ingest-and-cluster.md` | Parse artifacts, cluster, first-pass dispositions |
| `prompts/02-verify-cluster.md` | Human-grade verification of one cluster |
| `prompts/03-loe-and-tickets.md` | Effort and ticket text |
| `prompts/04-compose-handback.md` | Draft the updated handback.md |
| `prompts/05-delta-next-scan.md` | Process the *next* scan as a delta, not a restart |
| `prompts/06-merge-prior-rounds.md` | Collapse rounds 1–3 + Jira Units into stable Work Items |
| `MERGE-ROUNDS.md` | How R1/R2 Unit tickets relate to R3 LoE’d Highs |
| `Master-Index.xlsx` | Units ↔ findings ↔ Jira ↔ incoming match |
| `templates/JIRA-EXPORT.md` | Columns / JQL to pull the existing tickets |

## Already had three rounds?

Rounds 1–2 ticketed vendor **Units** (thin Jira, no severity split). Round 3 LoE’d exploitable Highs. Those Highs usually belong to a Unit you already ticketed.

Do this **before** reading the next `triage.md`:

1. Read `MERGE-ROUNDS.md`.
2. Export Jira with `templates/JIRA-EXPORT.md`.
3. Run prompt `06` against the three historical packages + the export.
4. Paste results into `Master-Index.xlsx`.
5. Incoming Highs go on **Round 4 match**. Inherit `use_existing`. Only `create` / `split_from_unit` / `ticket_stale` get human time.

## How to start the next package

1. Copy `templates/THREAT_MODEL.md` and fill it once. Reuse it every scan.
2. Copy `templates/DISMISSAL_RULES.md` and grow it every week.
3. Open `Disposition-Ledger.xlsx`, add a row on **Scans**, then ingest findings.
4. Paste `prompts/00-system-constraints.md` plus the relevant numbered prompt into the agent, with the scan artifacts and the two templates above.
5. Humans only adjudicate P0/P1 clusters and anything the agent marked `needs_human`.
6. Ship `templates/HANDBACK.md` filled from the ledger. Do not ship a novel.

## Definition of done for a two-week cycle

- Every scanner High has a verdict in the ledger.
- P0/P1 clusters have an owner, LoE, and intended fix shape.
- False positives and accepted risks have evidence, not vibes.
- Handback states clearly: reviewed, not remediated.
- Dismissal rules file grew by whatever this scan taught you.
