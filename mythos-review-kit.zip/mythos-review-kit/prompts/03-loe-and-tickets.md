# Prompt 03 — LoE and ticket text for confirmed clusters

Use Day 6. Attach constraints, threat model, verified cluster writeups (prompt 02 outputs), and any existing coding standards.

---

## Task

Turn confirmed clusters into engineering work the team can sequence *after* the next scan. There is no implementation window in this cycle.

## Rules

- One ticket per cluster, not per scanner ID.
- Put every scanner ID in the ticket body so the next scan can be matched.
- LoE is implementation effort on this legacy codebase, including tests and regression fear, not “how long to type a one-line fix.”
- Do not promise dates.
- Do not generate large patches unless asked. Fix *shape* only.
- Mark every ticket `Blocked-on-calendar: next scan will land before work starts`.

## Scale

- S: hours; local change; tests exist or are trivial
- M: 1–3 days; helper + multiple call sites + tests
- L: 1–2 sprints; behavior change across modules
- XL: program; architectural
- change-risk: low / medium / high

## Output

### Sequencing table

rank | cluster | our_sev | LoE | change-risk | why this order

### Ticket drafts

For each confirmed_reachable cluster:

```
Title: [P#][C-00X] short imperative

Body:
- Summary
- Why it matters in this product (not generic CWE text)
- Evidence (file:line)
- Scanner IDs included
- Preconditions
- Proposed fix shape
- Test plan
- Out of scope for this ticket
- Note: will still be reported on the next external scan; do not reopen as new work
```

### Parking lot

Clusters that are confirmed_not_reachable, P2/P3, or recommended accepted_risk — one table, no tickets unless the human asks.
