# Prompt 05 — Next scan is a delta, not a new project

Use the morning the following package arrives. Attach constraints, prior `HANDBACK.md`, prior ledger, current dismissal rules, threat model, and the new scan artifacts.

---

## Task

Classify every new High/Critical as one of:

| Delta class | Meaning | Action |
|---|---|---|
| `unchanged_repeat` | Same sink / same claim / code not materially changed | Inherit last verdict. Do not re-investigate. |
| `repeat_code_changed` | Same cluster, file moved or logic changed | Re-verify with prompt 02. |
| `new_cluster` | No parent in the ledger | Run through prompt 01 clustering, then 02 if it looks P0/P1. |
| `gone` | Previously open, absent now | Mark gone; do not assume fixed unless we shipped a change. |
| `severity_only_change` | Same bug, new scanner rating | Keep our severity unless new preconditions appear. |
| `noise` | Hallucinated path or dismissal-rule hit | `false_positive` / `out_of_scope` immediately. |

## Output

### A. Delta scoreboard

new package raw Highs vs matched repeats vs truly new vs gone

### B. Match table

new_id | prior_id / cluster | delta_class | inherited_verdict | reopen? | reason

### C. Work for this two-week window

Only list:
- new clusters
- repeats whose code changed
- prior P0/P1 still confirmed (one line each — already known work)

### D. Handback paragraph you can reuse

Two short paragraphs: “N of M Highs are unchanged repeats of handback [date]; we will not re-review them. The new work this cycle is: …”

### E. Quality note to the scanning party

If >50% of Highs are unchanged repeats with no delta file, say so plainly and repeat the Ask for a delta report.

## Rule

If you cannot match with reasonable confidence, mark `needs_human` rather than opening a new cluster. Duplicate tickets are more expensive than one extra human glance.
