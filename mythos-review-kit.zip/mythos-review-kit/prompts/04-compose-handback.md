# Prompt 04 — Draft the updated handback.md

Use Days 7–8. Attach constraints, `templates/HANDBACK.md`, the filled ledger (or cluster writeups + scoreboard), threat model date, dismissal rules date.

---

## Task

Fill `templates/HANDBACK.md` for the receiving/scanning party. This is a professional disposition package. It is not an apology and it is not a claim that the application is clean.

## Tone

- Neutral, specific, brief
- Distinguish *their* severity from *ours*
- State the calendar constraint once in section 1, then do not repeat it in every subsection
- Do not dump 96 narratives. Clusters and rule-level rejection summaries only
- Do not include exploit steps that would help a third party more than the recipient

## Required content

- Scoreboard with our labels
- Every P0/P1 confirmed cluster in section 5
- Rejections grouped by reason in section 7
- Concrete Asks: commit pin, JSON/SARIF, delta report, honor dismissals
- Explicit line: confirmed items will still appear on the next scan and should be matched, not re-opened

## Also produce

1. The filled `HANDBACK.md`
2. A 12-line executive note the review lead can paste into email (counts, top clusters, what we need from them)
3. A changelog of assumptions you had to make because artifacts were incomplete

## Do not

- Invent sign-off names or dates
- Mark accepted_risk without a human-supplied approver
- Claim a finding is fixed
- Soften P0 language if the cluster is truly P0
