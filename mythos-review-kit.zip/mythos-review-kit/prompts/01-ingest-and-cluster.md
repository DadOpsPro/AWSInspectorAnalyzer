# Prompt 01 — Ingest artifacts, cluster, first-pass dispositions

Use on Day 0. Attach: this prompt, `00-system-constraints.md`, threat model, dismissal rules, the full scan package, and the prior ledger if any.

---

## Task

Parse the scan package and produce a first-pass workbook the humans can accept or reject in hours, not days.

## Steps

1. Inventory artifacts. List each file and what it contains. Note whether a commit/hash is present. If missing, flag it as a handback Ask.
2. Extract every finding that the scanner called High or Critical (and any Medium the vendor `triage.md` still marked “Act on”).
3. Normalize each row:
   - scanner_id
   - title
   - class / CWE if present
   - path and line
   - scanner_severity
   - claimed preconditions (quote them; write `unstated` if absent)
   - short claim in one sentence
4. Cluster. Two findings share a cluster when one patch would close both. Name clusters `C-001`, `C-002`, …
5. Apply dismissal rules and the threat model. Propose a verdict per finding and per cluster.
6. Match prior-scan rows if a ledger is attached. Inherit verdicts when the code claim is unchanged.
7. Sort clusters: likely P0, likely P1, bulk-dismiss, needs_human.

## Output format

### A. Intake
- Scan identity
- Commit present?
- Raw counts
- Artifact notes

### B. Clusters (the page humans read)

For each cluster:

```
### C-00X — title
- Finding IDs:
- Module / path:
- Proposed our_severity:
- Proposed cluster_verdict:
- Why (3 bullets, evidence-bearing):
- Dismissal rule hit? 
- Prior match?
- Human needed? yes/no — question if yes
```

### C. Finding table

markdown table: scanner_id | cluster | title | path:line | scanner_sev | proposed_verdict | proposed_our_sev | rule_or_reason

### D. First-pass scoreboard
counts by proposed verdict

### E. Human queue
numbered questions only the SME can answer (is this shipped, is this internet-facing, is this admin-only)

### F. Suggested Day-1 auto-accepts
list of finding IDs you believe are safe to accept without a human reading the exploit narrative, and why

## Stop conditions

- Do not write tickets.
- Do not write patches.
- Do not invent reachability you did not see in code or in the threat model.
- If the package is too large, finish all Highs/Criticals before any Mediums. Say what you deferred.
