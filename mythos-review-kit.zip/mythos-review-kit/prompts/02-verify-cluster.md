# Prompt 02 — Verify one cluster against the codebase

Use Days 3–5. One cluster per session. Attach constraints, threat model, dismissal rules, the cluster rows from prompt 01, and the relevant source files (or grant repo read).

---

## Task

Adversarially check cluster **C-___**. Assume the scanner is over-claiming. Try to kill the finding. Only promote it if the path survives.

## Questions you must answer

1. Do the cited files, symbols, and lines exist on the tree I gave you? If not, `false_positive`.
2. What is the untrusted source? Where does it enter?
3. What is the sink? Is it actually dangerous in this language/framework?
4. What guards sit on the path (auth filter, allowlist, parameterization, encoding, network boundary)?
5. List preconditions an attacker must already satisfy. Count them.
6. Given `THREAT_MODEL.md`, is this surface shipped and in which trust zone?
7. If we fixed the root cause once, which other scanner IDs die?

## Output format

```
# C-00X verification

Verdict: ...
Our severity: ...
Confidence: high | medium | low

## Path
source → hops → sink (file:line each hop)

## Preconditions
1.
2.

## Why the scanner was right or wrong
- ...

## Why our severity differs from the scanner (if it does)
- ...

## Fix shape (not a patch)
- Root cause:
- Touch points:
- Tests that should exist after a fix:

## LoE suggestion
S/M/L/XL + change-risk low/medium/high + one sentence why

## Related IDs to collapse
- ...

## Human must decide
- accepted_risk? (only if real but we will not fix)
- needs_poc? (only if P0-plausible and static proof ran out)
```

## Effort cap

If you cannot finish in a tight static pass, stop and return `needs_human` with the exact question. Do not pad with a speculative exploit story.
