# Prompt 06 — Merge rounds 1–3 + Jira into a master work-item index

Use once before the fourth package, then reuse on every later scan.
Attach: `00-system-constraints.md`, this prompt, threat model, dismissal rules,
the three historical packages (handback + triage + any finding lists),
and a Jira export (CSV or pasted table).

---

## What changed across our rounds (tell the agent this)

We already ran three reviews. The process was not consistent, and the master
index has to respect that.

- **Rounds 1 and 2:** We opened **one Jira ticket per Unit** named in the vendor
  handback. Tickets are thin: little severity breakout, little per-finding
  detail, often no LoE.
- **Round 3:** We were required to add detail and to **LoE Highs we judged
  exploitable**. Some of those Highs belong to Units that already have a R1/R2
  ticket. Do not open a second ticket for the same Unit unless the claim is
  genuinely new.
- **Round 4 (incoming):** Match first. Only create work items / tickets for
  sinks that have no parent Unit, no Work Item, and no Jira.

## Task

Build a stable **Work Item** layer (`W-001` …) that sits above Units, findings,
and tickets.

A Work Item is the thing engineering would actually fix. Many scanner IDs,
and sometimes several Units, collapse into one Work Item when one patch
(or one existing ticket) would close them.

## Matching rules (apply in this order)

1. **Same vendor Unit ID** across packages → same Work Item.
2. **Same Jira key** already cited in a handback or ticket summary → same Work Item.
3. **Same scanner finding ID** re-reported → same Work Item.
4. **Same path + same class/CWE + line within 20** → same Work Item.
5. **Same sink / helper / missing control**, even if the file was renamed or
   the finding was filed under a new Unit → same Work Item. State the reason.
6. If none of the above: new Work Item.

When R3 added detail under a R1/R2 Unit, **do not split** that Unit into new
Work Items just because R3 listed more Highs. Attach the Highs as children.
Split only when R3 clearly describes a different root cause.

## Ticket rules

- R1/R2 Unit tickets stay the parent ticket for that Work Item.
- If R3 LoE’d an exploitable High that belongs to an existing Unit ticket,
  write the LoE **onto the Work Item / existing ticket**, do not draft a new key.
- Recommend a new ticket only when there is no Unit parent and no Jira match.
- If a Jira ticket is Done / Closed but the sink is still reported, mark
  `ticket_stale` — the next human question is “was the fix never shipped, or
  is the scanner blind to the fix?”

## Output

### A. Work Item index (the page we keep)

Table columns, exactly:

`work_item | title | root_cause | unit_ids | jira_keys | jira_status | first_seen_scan | last_seen_scan | our_severity | r3_exploitable | r3_loe | disposition | ticket_action | notes`

`ticket_action` must be one of:

- `use_existing` — already ticketed; update description/LoE only
- `create` — no parent ticket
- `split_from_unit` — R3 proved a second root cause hiding under one Unit
- `ticket_stale` — ticket closed, sink still reported
- `no_ticket` — FP / out of scope / not reachable; do not ticket

### B. Finding crosswalk

One row per historical finding / High you can extract:

`scan | scanner_id | unit_id | path | line | class | scanner_sev | work_item | jira_keys | match_rule (1–6) | confidence`

### C. Unit register (R1/R2 memory)

`unit_id | first_handback | jira_key | work_item | child_finding_count | still_present_r3 | comment`

### D. Conflicts the human must resolve

Only list:

- One Jira key pointing at two root causes
- One Unit that R3 split (or should split)
- Exploitable R3 High with no Unit and no Jira
- Closed ticket + still-present sink
- Same path, disagreeing verdicts across rounds

### E. Ready-for-round-4 cheat sheet

Short list the next agent should load first:

- Work Items still open / exploitable
- Jira keys that must be reused
- Units that are closed-as-noise and must not be re-ticketed
- Gaps (Highs R3 never dispositioned)

## Stop conditions

- Do not invent Jira keys.
- Do not invent Unit IDs. If a package has no Unit field, say `none` and match on path/sink.
- Do not write a new handback yet. This prompt only builds memory.
- If a source file is missing columns, extract what exists and list the gaps.
- Prefer over-collapsing into one Work Item over creating twins. Twins are how
  we got duplicate tickets last time.
