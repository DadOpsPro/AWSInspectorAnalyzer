# Combining rounds 1–3 before the next package

You already have three reviews and a pile of Unit-level Jira tickets that do
not line up cleanly with round-3 Highs. Do not start round 4 from `triage.md`.
Start from a **Work Item index**.

## What you actually have

| Round | What you produced | What that means now |
|---|---|---|
| 1 | One Jira per vendor **Unit**. Thin tickets. No real severity split. | Those tickets are the parent, even if they are vague. |
| 2 | Same pattern, more Units, possible second ticket on a Unit you already had. | Collapse duplicate Unit tickets onto one Work Item. |
| 3 | Detail + LoE on Highs you thought exploitable. | Those Highs are *children*. Attach LoE to the parent Unit ticket when it is the same sink. |
| 4 (next) | Another noisy High list. | Match to Work Items. Only new root causes get new tickets. |

A vendor **Unit** is their grouping, not yours. It is usually “a blob of related
claims from that package,” not “one patch.” R3 Highs often unpack a Unit into
several findings. That is expected. You still keep one engineering work item
until R3 proves a second root cause.

## Two-hour merge (do this before reading the new Highs)

1. Export Jira using `templates/JIRA-EXPORT.md`. Paste onto **Tickets**.
2. From each historical handback, list Units on **Units**. One row per Unit per
   round is fine; the sheet will roll them up.
3. From R3 (and any finding lists you still have from R1/R2), paste Highs onto
   **History**.
4. Run agent prompt `06` with the three packages + the Jira export. Paste its
   Work Item table onto **Work items**.
5. Fill **Work item** on Tickets, Units, and History. That single column is
   the join key for round 4.

You are done when every Jira key and every R3 exploitable High points at a
`W-xxx`, and the **Round 4 match** sheet can vlookup incoming IDs.

## Ticket policy going forward

| Situation | Action |
|---|---|
| Incoming High matches a Unit that already has Jira | `use_existing`. Comment LoE / evidence on the old ticket. |
| Two Jira keys for the same Unit (R1 and R2) | Keep the older key as parent. Close or link the newer as duplicate. |
| R3 exploitable High, no Unit, no Jira | `create` — this is real new work. |
| R3 High sits under a Unit but is a different root cause | `split_from_unit` — new Work Item, new ticket, link to the Unit ticket. |
| Jira Done/Closed, sink still in the new scan | `ticket_stale`. Do not open a twin until a human says the fix never shipped. |
| FP / not shipped / not reachable | `no_ticket`. Record it so round 4 does not reopen it. |

## What you tell the next agent

Paste this block at the top of the round-4 session, after `00` and `05`/`06`:

```
We have a master Work Item index. Reuse W-ids and Jira keys.
Rounds 1–2 ticketed by vendor Unit, with little detail.
Round 3 LoE’d exploitable Highs; those LoEs attach to the parent Work Item.
Do not open a new ticket when unit_ids or jira_keys is already populated.
Only create tickets when ticket_action = create.
```

## Definition of done for the merge

- [ ] Every R1/R2 Unit is on **Units** with its Jira key(s)
- [ ] Duplicate Unit tickets are linked
- [ ] Every R3 exploitable High is on **History** with a Work Item
- [ ] **Work items** sheet has LoE where R3 supplied it
- [ ] Incoming round-4 findings have a place to land (`Round 4 match`)
