---
description: Analyze one Mythos Critical or High finding against the scan commit and append the locked block to CRITICAL_and_HIGH_ANALYSIS.
argument-hint: <finding-id>
---

Analyze Mythos finding `$ARGUMENTS` using the mythos-crit-high skill.

Required context (ask if missing):
- Scan commit SHA
- Repo / unit
- Path to HANDBACK + TRIAGE (or the generated findings Excel/CSV)
- Local checkout of the application

Steps:
1. Load only this finding's row from the Excel/CSV or handback/triage.
2. Checkout or `git show` the scan commit. Do not use a dirty working tree.
3. Follow the skill decision order. Read real code. Do not trust the scanner writeup.
4. Append exactly one locked block to CRITICAL_and_HIGH_ANALYSIS. Nothing else in that file except prior blocks.
5. Stop. Do not start the next finding.
