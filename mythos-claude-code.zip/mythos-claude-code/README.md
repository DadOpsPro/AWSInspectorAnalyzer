# Mythos Critical / High analysis with Claude Code

Keep the existing Python workbook. Add a second, narrow pass that only
judges Critical and High against the real commit.

## Layout

```
.claude/skills/mythos-crit-high/SKILL.md   # decision order + locked output
.claude/commands/analyze-finding.md        # one-finding command
CLAUDE.md                                  # pin commit SHA + local URL
scripts/extract_crit_high.py               # build the Crit/High queue
```

Copy the `.claude/` tree and `CLAUDE.md` into the application repo (or a
sibling analysis repo that can read the application checkout).

## Pipeline

```
existing script
    → all-findings.xlsx          # unchanged; still the system of record
extract_crit_high.py
    → CRIT_HIGH_QUEUE.json       # work list for Claude Code
/analyze-finding <id>  (repeat)
    → CRITICAL_and_HIGH_ANALYSIS # locked text, one block per finding
human review of exploitable + need_runtime
    → Jira tickets               # business still gets one ticket per Crit/High
```

Do not put hundreds of findings in one Claude Code session. Context rot
is how scanner prose starts winning over the code.

## Operator loop

1. Generate the all-findings Excel with the current script.
2. Set the scan commit in `CLAUDE.md`. Create a clean worktree:

   ```
   git worktree add /tmp/app-scan <SCAN_SHA>
   ```

3. Build the queue:

   ```
   python3 scripts/extract_crit_high.py all-findings.xlsx --out-dir .
   ```

4. In Claude Code, from the analysis workspace:

   ```
   /analyze-finding ABC-123
   ```

5. After each block lands, glance at Verdict. Only `exploitable` and
   `need_runtime` need a person before the ticket is treated as real risk.
   Still open Jira for the rest if the business wants every Crit/High
   tracked; set disposition from the verdict.

## What Claude is allowed to decide

In this order, then stop:

1. Cited sink real?
2. Dead / not shipped / unreachable from the running local app?
3. Controls on this path?
4. Weakest attacker principal?
5. Local exploit difficulty?
6. Verdict: exploitable | not_exploitable | false_positive | dead_code | need_runtime

## Locked output

`CRITICAL_and_HIGH_ANALYSIS` contains only blocks like:

```
### [id] [type] [sink]
Verdict:
Attacker needs:
Mitigations in front:
Difficulty:
Summary:
Local test steps:
```

No headers, rollups, or confidence sections in that file.

## Jira

Create tickets from the workbook, not from Claude's memory.

Suggested ticket fields pulled from the Excel plus the analysis block:

- Summary: `[Mythos][sev][id] title`
- Description: file:line, scanner category, analysis Summary, verdict
- Labels: `mythos`, `crit`/`high`, verdict
- Do not paste Local test steps into a public or vendor-visible ticket
  if the ticket is broadly readable.

If many findings share one helper or one missing encoder, keep individual
tickets (business rule) but link them to a single root-cause epic.
