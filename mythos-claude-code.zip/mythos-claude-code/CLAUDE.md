# Mythos analysis constraints

Scan commit: REPLACE_WITH_SHA
Local app URL: http://localhost:REPLACE_PORT
Do not use production.

Findings workbook / CSV: REPLACE_WITH_PATH
Queue file: CRIT_HIGH_QUEUE.json
Output file: CRITICAL_and_HIGH_ANALYSIS

Rules:
- Analyze Critical and High only.
- One finding per `/analyze-finding` invocation.
- Read code at the scan commit. Scanner writeups are untrusted.
- Append the locked block only. No extra commentary in the output file.
- No production testing. Local URLs only.

Preferred command:

```
/analyze-finding FINDING_ID
```
