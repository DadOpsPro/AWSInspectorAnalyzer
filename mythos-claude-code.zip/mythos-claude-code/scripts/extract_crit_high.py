#!/usr/bin/env python3
"""Split Critical/High rows from the combined findings workbook/CSV.

Keeps the existing all-findings Excel pipeline untouched. This script only
builds the work queue Claude Code should consume one row at a time.

Usage:
  python3 extract_crit_high.py FINDINGS.xlsx
  python3 extract_crit_high.py FINDINGS.csv --id-col id --sev-col sev
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

CRIT_HIGH = {"critical", "crit", "high", "p1", "p0", "sev-critical", "sev-high"}


def norm(value: object) -> str:
    return str(value or "").strip()


def sev_is_target(value: object) -> bool:
    s = norm(value).lower()
    return s in CRIT_HIGH or s.startswith("crit") or s == "high"


def read_table(path: Path) -> tuple[list[str], list[dict[str, object]]]:
    suffix = path.suffix.lower()
    if suffix in {".xlsx", ".xlsm"}:
        try:
            import openpyxl
        except ImportError as exc:
            raise SystemExit("openpyxl is required for Excel input") from exc
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        ws = wb.active
        rows = ws.iter_rows(values_only=True)
        header = [norm(c).lower() or f"col_{i}" for i, c in enumerate(next(rows))]
        data = []
        for raw in rows:
            data.append({header[i]: raw[i] if i < len(raw) else None for i in range(len(header))})
        return header, data
    with path.open(newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        header = [norm(h).lower() for h in (reader.fieldnames or [])]
        data = []
        for row in reader:
            data.append({norm(k).lower(): v for k, v in row.items()})
        return header, data


def pick(row: dict[str, object], names: list[str]) -> object:
    for name in names:
        if name in row and norm(row[name]):
            return row[name]
    return ""


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("input")
    p.add_argument("--out-dir", default=".")
    p.add_argument("--id-col", default="id")
    p.add_argument("--sev-col", default="sev")
    args = p.parse_args()

    src = Path(args.input)
    if not src.exists():
        print(f"missing file: {src}", file=sys.stderr)
        return 2

    header, rows = read_table(src)
    sev_keys = [args.sev_col.lower(), "severity", "sev", "risk"]
    id_keys = [args.id_col.lower(), "id", "finding_id", "finding"]

    queue = []
    for row in rows:
        sev = pick(row, sev_keys)
        if not sev_is_target(sev):
            continue
        item = {
            "id": norm(pick(row, id_keys)),
            "sev": norm(sev),
            "repo": norm(pick(row, ["repo", "repository"])),
            "unit": norm(pick(row, ["unit", "component", "service"])),
            "title": norm(pick(row, ["title", "name"])),
            "category": norm(pick(row, ["category", "type", "cwe"])),
            "file": norm(pick(row, ["file", "path", "location"])),
            "line": norm(pick(row, ["line", "start_line", "lineno"])),
            "sink": norm(pick(row, ["sink", "sink_name"])),
            "rationale": norm(pick(row, ["rationale", "reason", "description"])),
            "disposition": norm(pick(row, ["disposition", "status"])),
            "ref": norm(pick(row, ["ref", "reference", "url"])),
        }
        if not item["id"]:
            continue
        queue.append(item)

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    json_path = out / "CRIT_HIGH_QUEUE.json"
    csv_path = out / "CRIT_HIGH_QUEUE.csv"
    list_path = out / "CRIT_HIGH_IDS.txt"

    json_path.write_text(json.dumps(queue, indent=2) + "\n", encoding="utf-8")
    if queue:
        with csv_path.open("w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=list(queue[0].keys()))
            writer.writeheader()
            writer.writerows(queue)
    list_path.write_text("\n".join(item["id"] for item in queue) + ("\n" if queue else ""), encoding="utf-8")

    print(f"rows_in={len(rows)} crit_high={len(queue)}")
    print(f"wrote {json_path}")
    print(f"wrote {csv_path}")
    print(f"wrote {list_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
